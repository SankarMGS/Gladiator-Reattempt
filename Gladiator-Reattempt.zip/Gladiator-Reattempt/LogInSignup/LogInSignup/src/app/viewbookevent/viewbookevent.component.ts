import { Component, OnInit } from '@angular/core';
import { VieweventService } from '../service/viewevent.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewbookevent',
  templateUrl: './viewbookevent.component.html',
  styleUrls: ['./viewbookevent.component.css']
})
export class ViewbookeventComponent implements OnInit {

  NewElement : any[] =[]
  constructor(private veiwevent : VieweventService, private http : HttpClient, private router : Router){}
  ngOnInit(): void {
    this.veiwevent.getdata().subscribe((res : any)=>{
        var js = JSON.stringify(res);
        var jres = JSON.parse(js);
        console.log(jres);
        this.NewElement=jres.response
        
    })
  }

  delete(id : number){
    const url = 'https://localhost:44334/api/controller/Delete?eventId';
    this.http.delete(`${url}=${id}`).subscribe(response =>{
      console.log(response);
      //this.router.navigateByUrl('user/viewevent');
      window.location.reload();
    })
    
  }

}
