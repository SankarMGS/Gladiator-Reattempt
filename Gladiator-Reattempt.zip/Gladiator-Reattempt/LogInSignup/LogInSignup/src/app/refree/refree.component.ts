import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { RefreeService } from '../service/refree.service';

export class refreemodel{
  refereeName = '';
  noOfMatches = '';
}
@Component({
  selector: 'app-refree',
  templateUrl: './refree.component.html',
  styleUrls: ['./refree.component.css']
})
export class RefreeComponent implements OnInit{
  refreeForm! : FormGroup;
  getRefree : any[] = []
constructor(private http : HttpClient, private formbuilder : FormBuilder, private refreeservice: RefreeService){}
  ngOnInit(): void {
    this.refreeForm = this.formbuilder.group({
      refereeName :[''],
      noOfMatches :['']
    });

    this.refreeservice.getrefree().subscribe((res : any)=>{
      var js = JSON.stringify(res);
      var jres = JSON.parse(js);
      console.log(jres);
      this.getRefree = jres.response;
      
    })
  }

  onSubmit() : void {
    if(this.refreeForm.valid){
      this.refreeservice.createrefree(this.refreeForm.value).subscribe(res =>{
        console.log(res);
      });
      window.location.reload();
    }
  }

  delete(id : number){
    const  url = 'https://localhost:44334/api/Referee/deleteReferee?refereeId';
    this.http.delete(`${url}=${id}`).subscribe(res =>{
      console.log(res);
      window.location.reload();
      
    })
  }

}
