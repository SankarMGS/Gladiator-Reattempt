import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RefreeComponent } from '../refree/refree.component';
import { map } from 'rxjs/internal/operators/map';

const url = 'https://localhost:44334/api/Referee/addReferee';
@Injectable({
  providedIn: 'root'
})
export class RefreeService {

  constructor(private http : HttpClient) { }

  createrefree(data : RefreeComponent){
    return this.http.post<RefreeComponent>(url,data);
  }

  getrefree(){
    return this.http.get<any>('https://localhost:44334/api/Referee/getReferee').pipe(map((res : any)=>{
      return res;
    }))
  }
}
