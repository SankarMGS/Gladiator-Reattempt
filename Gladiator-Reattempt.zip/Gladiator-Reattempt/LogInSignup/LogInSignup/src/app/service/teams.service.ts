import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TeamsComponent } from '../teams/teams.component';
import { map } from 'rxjs/operators';

const url= 'https://localhost:44334/api/Team/addTeam';
@Injectable({
  providedIn: 'root'
})
export class TeamsService {

  constructor(private http : HttpClient) { }

  createTeam(data : TeamsComponent){
    return this.http.post<TeamsComponent>(url,data);
  }

  getTeam(){
    return this.http.get<any>('https://localhost:44334/api/Team/getTeam').pipe(map((res : any)=> {
      return res;
    }))
  }
}
