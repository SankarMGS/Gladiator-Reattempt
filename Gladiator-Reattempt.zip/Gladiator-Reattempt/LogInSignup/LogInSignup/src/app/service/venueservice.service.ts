import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { VenuesComponent } from '../venues/venues.component';
import { map } from 'rxjs';


const url = 'https://localhost:44334/api/Venue/CreateVenue';
@Injectable({
  providedIn: 'root'
})


export class VenueserviceService {

  constructor(private http : HttpClient) { }

  venuepost(data:VenuesComponent ){
    return this.http.post<VenuesComponent>(url, data);
  }

  getvenues(){
    return this.http.get<any>('https://localhost:44334/api/Venue/ReadVenue').pipe(map((res : any)=>{
      return res;
    }))
  }
}
