import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-event',
  templateUrl: './bookevent.component.html',
  styleUrls: ['./bookevent.component.css']
})
export class EventComponent implements OnInit
{
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  constructor(private http : HttpClient, private toastr : ToastrService){}

  eventwork: any;
  // ngOnInit(): void {
  //   throw new Error('Method not implemented.');
  // }

  // eventmodule:Event[]=[];
  // event: Event=
  // {
  //   eventId:'',
  //   eventName:'',
  //   applicantName:'',
  //   applicantAddress:'',
  //   applicantMobile:'',
  //   applicantEmail:'',
  //   eventAddress:'',
  //   eventFromDate:'',
  //   eventToDate:'',

  // }

  // onSubmit(){
  //   this.eventwork.Create(this.user)
  //   .subscribe(
  //     (response)=>{
  //       this.getallproducts();
  //       this.user =
  //       {
  //         eventId:'',
  //         eventName:'',
  //         applicantName:'',
  //         applicantAddress:'',
  //         applicantMobile:'',
  //         applicantEmail:'',
  //         eventAddress:'',
  //         eventFromDate:'',
  //         eventToDate:'',   
  //       }  
  //     })
  // }
  // getallproducts() {
  //   throw new Error('Method not implemented.');
  // }
  

  loginForm=new FormGroup(
  {
    EventName:new FormControl(''),
    ApplicantName:new FormControl(''),
    ApplicantAddress: new FormControl(''),
    ApplicantMobile:new FormControl(''),
    ApplicantEmail:new FormControl(''),
    EventAddress:new FormControl(''),
    EventFromDate:new FormControl(''),
    EventToDate:new FormControl('')
    
  })
  onSubmit()
  {
    console.log(this.loginForm.value);
    this.http.post('https://localhost:44334/api/controller/create',this.loginForm.value).subscribe(response =>{
      console.log(response);
      this.toastr.success("Event Booked !");
      
    }, error =>{
      console.log(error);
      this.toastr.error("Event booking failed");
    })
  }

}
