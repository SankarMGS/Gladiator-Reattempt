import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule, Route, Routes } from '@angular/router';
import { RouterOutlet} from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';

import { RegisterModel, SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';

import { LoginService } from 'src/app/service/login.service';
import { RegisterService } from 'src/app/service/register.service';
import { AdminComponent } from './admin/admin.component';
import { ToastrModule } from 'ngx-toastr';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { UserComponent } from './user/user.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { EventComponent } from './bookevent/bookevent.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ViewbookeventComponent } from './viewbookevent/viewbookevent.component';
import { VenuesComponent } from './venues/venues.component';
import { AdminnavComponent } from './adminnav/adminnav.component';
import { TeamsComponent } from './teams/teams.component';
import { RefreeComponent, refreemodel } from './refree/refree.component'



const routes: Routes = [
  {path:'',redirectTo:'user/login',pathMatch:'full'},
  { path: 'user/login', component:LoginComponent},
  //{ path: 'logout', component: LoginComponent },
    { path: 'user/signup', component : SignupComponent},
    { path : 'admin', component : AdminComponent },
    {path: 'register', component : UserComponent },
    {path : 'user/homepage',component: UserhomeComponent},
    {path : 'user/bookevent' , component : EventComponent},
    {path : 'user/viewevent' , component : ViewbookeventComponent},
    {path : 'admin/venue', component : VenuesComponent},
    {path : 'admin/teams' , component : TeamsComponent},
    {path : 'admin/refree', component : RefreeComponent}
  ];
@NgModule({
  declarations: [
    AppComponent,
    
    SignupComponent,
    LoginComponent,
    AdminComponent,
    UserComponent,
    UserhomeComponent,
    EventComponent,
    ViewbookeventComponent,
    VenuesComponent,
    AdminnavComponent,
    TeamsComponent,
    RefreeComponent,
     
    
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    NgbModule,
    

  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
}
