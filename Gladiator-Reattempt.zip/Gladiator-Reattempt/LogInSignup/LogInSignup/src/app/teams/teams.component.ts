import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TeamsService } from '../service/teams.service';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';

export class teammodel {
  teamName = '';
  teamDescription = '';
  noOfplayers = '';
  TeamLocation = '';
  FirstName = '';
  LastName = '';
  Age = '';
  Gender = '';
}
@Component({
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.css']
})
export class TeamsComponent implements OnInit {
  public teamForm!: FormGroup;
  public GetTeams: any[] = []

  constructor(private formbuilder: FormBuilder, private teamservice: TeamsService, private toastr: ToastrService, private http: HttpClient) { }
  ngOnInit(): void {
    this.teamForm = this.formbuilder.group({
      teamName: ['', Validators.required],
      teamDescription: ['', Validators.required],
      noOfplayers: ['', Validators.required],
      TeamLocation: ['', Validators.required],
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required],
      Age: ['', Validators.required],
      Gender: ['', Validators.required]
    });

    this.teamservice.getTeam().subscribe((res: any) => {
      var js = JSON.stringify(res);
      var jres = JSON.parse(js);
      console.log(jres);
      this.GetTeams = jres.response

    });
  }

  onSubmit(): void {
    if (this.teamForm.valid) {
      this.teamservice.createTeam(this.teamForm.value).subscribe(res => {
        { console.log(res) }
      });
      this.toastr.success("Team Added Successfully");
      window.location.reload();
    } else {
      this.toastr.error("Not added");
    }
  }

  delete(id: number) {
    const url = 'https://localhost:44334/api/Team/deleteTeam?teamId';
    this.http.delete(`${url}=${id}`).subscribe(res => {
      console.log(res);
      window.location.reload();
      // this.toastr.success("Deleted team");
     
    })
  }

}
