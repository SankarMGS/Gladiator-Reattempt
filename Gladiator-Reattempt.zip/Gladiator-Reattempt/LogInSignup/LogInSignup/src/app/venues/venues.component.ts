import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VenueserviceService } from '../service/venueservice.service';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';


export class venuemodel{
   venueName = '' ;
   venueImageURL = '';
   venueDescription = '';
   VenueLocation = '';

}
@Component({
  selector: 'app-venues',
  templateUrl: './venues.component.html',
  styleUrls: ['./venues.component.css']
})
export class VenuesComponent implements OnInit{
 public venue! : FormGroup;
 public GetnewData : any [] = []
constructor(private formBuilder : FormBuilder, private venueservice : VenueserviceService, private toastr : ToastrService , private http : HttpClient){}


  ngOnInit(): void {
    
    this.venue =  this.formBuilder.group({
      venueName : ['', Validators.required],
      venueImageURL : ['',Validators.required],
      venueDescription : ['',Validators.required],
      VenueLocation : ['',Validators.required]
    });

    this.venueservice.getvenues().subscribe((res : any)=>{
      var js = JSON.stringify(res);
      var jres = JSON.parse(js);
      console.log(jres);
      this.GetnewData = jres.response
      
    })
  }

onSubmit() : void{
if(this.venue.valid){
  this.venueservice.venuepost(this.venue.value).subscribe(res =>{
    {console.log(res)}
  });

  this.toastr.success("Venue Added successfully");
  // this.venue.reset();
  window.location.reload();
}else{
  this.toastr.error("venue adding failed");
}


}

delete(id : number){
  const url = 'https://localhost:44334/api/Venue/DeleteVenue?VenueId';
  this.http.delete(`${url}=${id}`).subscribe(res => {
    console.log(res);
    this.toastr.success("deleted");
    window.location.reload();
    
  })
}




}