﻿using CricketManagement.Context;
using CricketManagement.Core.Interface;
using CricketManagement.Models;
using System.Collections.Generic;
using System.Linq;

namespace CricketManagement.Core
{
    public class TeamCore : ITeamCore
    {
        private readonly CricketContext _teamContext;
        public TeamCore(CricketContext teamContext)
        {
            this._teamContext = teamContext;
        }

        public string addTeam(TeamModel teamModel)
        {
            try
            {
                _teamContext.teamModels.Add(teamModel);
                _teamContext.SaveChanges();
                return "added successfully";

            }
            catch
            {
                throw;
            }
        }

        public string deleteTeam(int teamId)
        {
            try
            {
                var tm = _teamContext.teamModels.Find(teamId);

                if (tm != null)
                {
                    _teamContext.Remove(tm);
                    _teamContext.SaveChanges();
                    return "Team deleted successfully";

                }
                return $"No team found with id{teamId}";
            }
            catch
            {
                throw;
            }
        }

        public string editTeam(TeamModel team, int teamId)
        {
            try
            {

                var tm = _teamContext.teamModels.Find(teamId);
                if (tm != null)
                {
                    //tm.teamId = team.teamId;
                    tm.teamName = team.teamName;
                    tm.teamDescription = team.teamDescription;
                    tm.TeamLocation = team.TeamLocation;
                    tm.FirstName = team.FirstName;
                    tm.LastName = team.LastName;
                    tm.Age = team.Age;
                    tm.Gender = team.Gender;
                    tm.noOfplayers = team.noOfplayers;
                    _teamContext.teamModels.Update(tm);
                    _teamContext.SaveChanges();
                    return "Teams updated successfully";

                }
                return $"No data found{team.teamId}";


            }
            catch 
            {
                throw;
            }
        }

        public IEnumerable<TeamModel> read()
        {
            var res = _teamContext.teamModels.ToList();
            
            return res;
        }
    }
}
