﻿using CricketManagement.Models;
using Microsoft.EntityFrameworkCore;
using CricketManagement.Context;
using CricketManagement.Core.Interface;
using yogatraininghiringsystemproject.Core.Interface;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CricketManagement.Core
{
    public class User : IUser
    {
        private readonly CricketContext _context;
        public User(CricketContext context)
        {
            _context = context;
        }
        public async Task<UserModel> addUser(UserModel data)
        {
            try
            {
                if (data != null)
                {


                   await _context.userModels.AddAsync(data);
                   await _context.SaveChangesAsync();
                    return data;
                    // _context.SaveChanges();
                    //var role = data.UserRole.ToLower();
                    //if (role == "admin")
                    //{
                    //    AdminModel admin = new AdminModel();
                    //    admin.Email = data.Email;
                    //    admin.Password = data.Password;
                    //    admin.MobileNumber = data.MobileNumber;
                    //    admin.UserRole = data.UserRole;

                    //    _context.adminModels.Add(admin);
                    //}
                    ////_context.SaveChanges();
                    //LoginModel login = new LoginModel();
                    //login.Email = data.Email;
                    //login.Password = data.Password;
                    //_context.loginModels.Add(login);
                    //_context.SaveChanges();
                    //return 

                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        public async Task<UserModel> deleteUser(string UserID)
        {
            try
            {
                var response = await _context.userModels.FindAsync(UserID);
                await _context.SaveChangesAsync();
                return response;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<UserModel> editUser(int id, UserModel data)
        {
            try
            {
                var response =await _context.userModels.FindAsync(id);
                if(response != null)
                {
                    response.Email = data.Email;
                    response.UserRole= data.UserRole;
                    response.UserName = data.UserName;
                    response.Password = data.Password;
                    response.MobileNumber = data.MobileNumber;
                    _context.userModels.Update(response);
                    await _context.SaveChangesAsync();
                    return response;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {

                throw;
            }
            //var role = _context.userModels.Where(x => x.UserId == data.UserId).Select(y => y.UserRole).First();
            //role = role.ToLower();
            //if (role == "admin")
            //{
            //    var k = _context.userModels.Find(data.UserId);
            //    if (k != null)
            //    {
            //        var admin = _context.adminModels.Where(x => x.Email == k.Email).First();
            //        var login = _context.loginModels.Where(x => x.Email == k.Email).First();
            //        k.MobileNumber = data.MobileNumber;
            //        k.UserName = data.UserName;
            //        k.Email = data.Email;
            //        k.Password = data.Password;


            //        k.UserRole = data.UserRole;
            //        _context.userModels.Update(k);

            //        admin.Email = data.Email;
            //        admin.Password = data.Password;
            //        admin.MobileNumber = data.MobileNumber;
            //        admin.UserRole = data.UserRole;
            //        _context.adminModels.Update(admin);

            //        login.Email = data.Email;
            //        login.Password = data.Password;
            //        _context.loginModels.Update(login);
            //        _context.SaveChanges();
            //        return "User Editted";
            //    }
            //    else
            //    {
            //        return "User not edited";
            //    }

            //}
            //else
            //{

            //    var i = _context.userModels.Find(data.UserId);
            //    if (i != null)
            //    {
            //        var login = _context.loginModels.Where(x => x.Email == i.Email).First();
            //        i.MobileNumber = data.MobileNumber;
            //        i.UserName = data.UserName;
            //        i.Email = data.Email;
            //        i.Password = data.Password;


            //        i.UserRole = data.UserRole;
            //        _context.userModels.Update(i);

            //        login.Email = data.Email;
            //        login.Password = data.Password;
            //        _context.loginModels.Update(login);
            //        _context.SaveChanges();
            //        return "User Editted";
            //    }
            //    else
            //    {
            //        return "User not edited";
            //    }
            }
        

        public async Task<UserModel> getUser(string UserID)
        {
            try
            {
                int userID = Convert.ToInt32(UserID);
                var i = await _context.userModels.FindAsync(userID);
                if (i != null)
                {

                    return i;

                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}
