﻿
using CricketManagement.Core.Interface;
using CricketManagement.Context;
using CricketManagement.Models;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace CricketManagement.Core
{
    public class EventCore : IEvent
    { 
        private readonly CricketContext _context;

        public EventCore(CricketContext context)
        {
            _context = context;
        }

        public async Task<string> CreateEvent(EventModel eventModel)
        {
             try
             {   
                if (eventModel != null)
                {
                    var acc =await  _context.EventTable.AddAsync(eventModel);
                    await _context.SaveChangesAsync ();
                    return "create is Done";
                }
                else
                {
                    return "Create is failed";
                }
                     
             }
             catch (Exception)
             {

                throw;
             }
        }

        public async Task<IEnumerable<EventModel>> ReadByEvents()
        {
            try
            {
                var acc = await _context.EventTable.ToListAsync();
                if (acc != null)
                {
                    
                    return acc;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<string> UpdateEvent(EventModel eventModel,int eventId)
        {
            try
            {

                var acc = await _context.EventTable.FindAsync(eventId);
                if (acc != null)
                {
                    acc.EventName = eventModel.EventName;
                    acc.ApplicantName = eventModel.ApplicantName;
                    acc.ApplicantAddress = eventModel.ApplicantAddress;
                    acc.ApplicantMobile = eventModel.ApplicantMobile;
                    acc.ApplicantEmail = eventModel.ApplicantEmail;
                    acc.EventAddress = eventModel.EventAddress;
                    acc.EventFromDate = eventModel.EventFromDate;
                    acc.EventToDate = eventModel.EventToDate;
                    _context.EventTable.Update(acc);
                   await _context.SaveChangesAsync();
                    return "Update is Create";
                }
                else
                {
                    return "Show some Exception error";
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<string> DeleteEvent(int eventId)
        {
            try
            {
                var acc = await _context.EventTable.FindAsync(eventId);

                if (acc != null)
                {
                    _context.EventTable.Remove(acc);
                    await _context.SaveChangesAsync();
                    return "Delete the Event";
                }
                return "NOT DELETED EVENT ";

            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
