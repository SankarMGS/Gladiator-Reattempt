﻿using CricketManagement.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CricketManagement.Core.Interface
{
    public interface IVenue
    {
        Task<VenueModel> CreateVenue(VenueModel venueModel);
        Task<IEnumerable<VenueModel>> ReadVenue();
        Task<VenueModel> UpdateVenue(VenueModel venuemodel,int VenueId);
        Task<VenueModel> DeleteVenue(int VenueId);

        
    }
}
