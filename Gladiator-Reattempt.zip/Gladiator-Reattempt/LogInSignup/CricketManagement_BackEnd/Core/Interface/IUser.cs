﻿using CricketManagement.Models;
using System.Threading.Tasks;

namespace CricketManagement.Core.Interface
{
    public interface IUser
    {
        Task<UserModel> addUser(UserModel data);
        Task<UserModel> getUser(string UserID);
        Task<UserModel> editUser(int id,UserModel data);
        Task<UserModel> deleteUser(string UserID);
    }
}
