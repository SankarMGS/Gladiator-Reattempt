﻿using CricketManagement.Models;
using System.Threading.Tasks;

namespace yogatraininghiringsystemproject.Core.Interface
{
    public interface IAuth 
    {
        Task<ResponseModel> RegisterUser(UserModel userModel);
        ResponseModel GenerateToken(LoginModel loginModel);
    }
}
