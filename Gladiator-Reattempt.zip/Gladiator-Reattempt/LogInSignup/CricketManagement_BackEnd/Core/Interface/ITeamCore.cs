﻿
using CricketManagement.Models;
using System.Collections.Generic;

namespace CricketManagement.Core.Interface
{
    public interface ITeamCore
    {
        // Task<ResponseModel> addTeam(TeamModel teamModel);
        //IEnumerable<TeamModel> ReadAllTeam();


        IEnumerable<TeamModel> read();
        string addTeam(TeamModel teamModel);
        string editTeam(TeamModel team, int teamId);
        string deleteTeam(int teamId);
    }
}
