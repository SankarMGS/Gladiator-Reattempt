﻿using CricketManagement.Models;
using System.Collections.Generic;

namespace CricketManagement.Core.Interface
{
    public interface IReferee
    {
       

        IEnumerable<RefereeModels> read();

       public string addReferee(RefereeModels refereemodel);
       public string editReferee(int refereeID, RefereeModels referee);

        public string deleteReferee(int idrefereeID);
    }
}
