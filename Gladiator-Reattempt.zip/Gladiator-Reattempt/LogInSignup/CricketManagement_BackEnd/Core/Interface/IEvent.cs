﻿using CricketManagement.Models;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace CricketManagement.Core.Interface
{
    public interface IEvent
    {
       
        Task<string> CreateEvent(EventModel eventModel);
        Task<IEnumerable<EventModel>> ReadByEvents();
        Task<string> UpdateEvent(EventModel eventModel,int eventId);
        Task<string> DeleteEvent(int eventId);

    }
}
