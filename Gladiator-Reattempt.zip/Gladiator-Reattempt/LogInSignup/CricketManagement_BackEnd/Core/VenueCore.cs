﻿using System.Collections.Generic;
using System;
using System.Linq;
using CricketManagement.Context;
using CricketManagement.Models;
using CricketManagement.Core.Interface;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace VenueManagement.Core
{
    public class Venue : IVenue
    {
        private readonly CricketContext venueContext;
        public Venue(CricketContext VenueContext)
        {
            this.venueContext = VenueContext;

        }

        public async Task<VenueModel> CreateVenue(VenueModel venue)
        {
            try
            {
                await venueContext.AddAsync(venue);
                await venueContext.SaveChangesAsync();
                return venue;
            }
            catch (Exception)
            {
                throw;
            }
            throw new NotImplementedException();
        }


        public async Task<VenueModel> DeleteVenue(int id)
        {
            try
            {
                var venue = await venueContext.Venuetable.FindAsync(id);
                if (venue != null)
                {
                     venueContext.Remove(venue);
                    await venueContext.SaveChangesAsync();
                    return venue;
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //public async Task<IEnumerable<VenueModel>> ReadVenue(i)
        //{
        //    try
        //    {
        //        return venueContext.Venuetable.ToList();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}

        public async Task<IEnumerable<VenueModel>> ReadVenue()
        {
            try
            {
                var response = await venueContext.Venuetable.ToListAsync();
               
                if (response != null)
                {
                    return response;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        public async Task<VenueModel> UpdateVenue(VenueModel venuemodel, int venueid)
        {
            try
            {
                var venue =await venueContext.Venuetable.FindAsync(venueid);

                if (venue != null)
                {
                    venue.venueName = venuemodel.venueName;
                    venue.venueImageURL = venuemodel.venueImageURL;
                    venue.venueDescription = venuemodel.venueDescription;
                    venue.VenueLocation = venuemodel.VenueLocation;
                    venueContext.Venuetable.Update(venue);
                    await venueContext.SaveChangesAsync();
                    return venue;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }
}








