﻿
using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Policy;

namespace CricketSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RefereeController : ControllerBase
    {
        private readonly IReferee _ireferee;
        

        public RefereeController(IReferee ireferee)
        {
            this._ireferee = ireferee;
        }

        [HttpGet]
        [Route("getReferee")]

        public ResponseModel readbyid()
        {
            ResponseModel responseModel = null;
            try
            {
                var res = _ireferee.read();
                responseModel = new ResponseModel();
                responseModel.Response = res;
                responseModel.Status = true;
                responseModel.Message = "Success";
                return responseModel;

            }
            catch
            {
                throw;
            }
        }


        [HttpDelete]
        [Route("deleteReferee")]



        public ResponseModel deleteReferee(int refereeId)
        {
            ResponseModel responseModel = null;
            try
            {
                var res = _ireferee.deleteReferee(refereeId);
                responseModel = new ResponseModel();
                responseModel.Response = res;
                responseModel.Status = true;
                responseModel.Message = "Success";
                return responseModel;
            }
            catch
            {
                throw;
            }
        }

        [HttpPost]
        [Route("addReferee")]



        public IActionResult addReferee(RefereeModels refereeModel)
        {
            try
            {
                var res = _ireferee.addReferee(refereeModel);
                return Ok(res);
            }
            catch
            {
                throw;
            }
        }

        [HttpPut]
        [Route("editReferee")]



        public string editReferee(int refereeID, RefereeModels referee)

        {
            try
            {
                var res = _ireferee.editReferee(refereeID, referee);
                return res;
            }
            catch
            {
                throw;
            }
        }
    }
}





    
