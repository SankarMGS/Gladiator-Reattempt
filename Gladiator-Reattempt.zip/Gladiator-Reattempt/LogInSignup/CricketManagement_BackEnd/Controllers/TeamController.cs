﻿//using CricketManage_db.Context;


using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace CricketManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class TeamController:ControllerBase
    {
        private readonly ITeamCore iteamint;
        private readonly ILogger<TeamController> logger;
        public TeamController(ITeamCore iteamint, ILogger<TeamController> logger)
        {
            this.iteamint = iteamint;
            this.logger = logger;
        }


        [HttpGet]
        [Route("getTeam")]

        public ResponseModel read()
        {
            ResponseModel responseModel = null;
            try
            {
                var res = iteamint.read();
                responseModel = new ResponseModel();
                if(res != null)
                {
                    responseModel.Response = res;
                    responseModel.Status = true;
                    responseModel.Message = "Success";
                    return responseModel;
                }
                else
                {
                    responseModel = new ResponseModel();
                    responseModel.Status = false;
                    responseModel.Message = "Failure";
                    responseModel.ErrorMessage = "Somthing went wrong";
                    return responseModel;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpDelete]
        [Route("deleteTeam")]

        public ResponseModel deleteTeam(int teamId)
        {
            ResponseModel  responseModel = new ResponseModel();
            try
            {
                var response = iteamint.deleteTeam(teamId);
                responseModel.Response= response;
                responseModel.Status = true;
                responseModel.Message = "Success";
                return responseModel;
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("addTeam")]

        public IActionResult addTeam(TeamModel teamModel)
        {
            try
            {
                var response = iteamint.addTeam(teamModel);
                return Ok(response);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("editTeam")]

        public IActionResult editTeam(TeamModel team, int teamId)
        {
            try
            {
                var response = iteamint.editTeam(team, teamId);
                return Ok(response);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
