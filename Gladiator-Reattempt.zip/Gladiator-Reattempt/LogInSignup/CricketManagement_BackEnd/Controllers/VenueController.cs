﻿using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using VenueManagement.Core;

namespace VenueManagement1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VenueController : ControllerBase
    {
        private readonly IVenue venue;
        public VenueController(IVenue venue)
        {
            this.venue = venue;
        }

        [HttpGet]
        [Route("ReadVenue")]
        public async Task<ResponseModel> ReadVenue()
        {
            ResponseModel responseModel = null;
            try
            {
                var response = await venue.ReadVenue();
                if (response != null)
                {
                    responseModel = new ResponseModel();
                    responseModel.Response = response;
                    responseModel.Status = true;
                    responseModel.Message = "element";
                    return responseModel;
                }
                else
                {
                    responseModel.Message = "no such event";
                    responseModel.Status = false;
                    responseModel.ErrorMessage = "Somthing went wrong";
                    return responseModel;
                }


            }
            catch (Exception ex)
            {
                responseModel = new ResponseModel();
                responseModel.Status = false;
                responseModel.Message = "Failure";
                responseModel.ErrorMessage= ex.Message;
                return responseModel;
            }
        }
        [HttpPost]
        [Route("CreateVenue")]
        public async Task<ResponseModel> CreateVenue(VenueModel Venue)
        {
            ResponseModel responseModel = null;
            try
            {
                responseModel = new ResponseModel();
                var response = await venue.CreateVenue(Venue);
                if (response != null)
                {
                    responseModel.Response = new
                    {
                        Venue.venueName,
                        Venue.venueImageURL,
                        Venue.venueDescription,
                        Venue.VenueLocation,
                        Venue.venueId
                    };
                    responseModel.Status = true;
                    responseModel.Message = "Success";
                    return responseModel;
                }
                else
                {
                    responseModel = new ResponseModel();    
                    responseModel.Status = false;
                    responseModel.Message = "failure";
                    return responseModel;
                }
                
            }
            catch (Exception ex)
            {
                responseModel = new ResponseModel();
                responseModel.Status = true;
                responseModel.Message = "Failure";
                responseModel.ErrorMessage = ex.Message;
                return responseModel;
            }
        }



        [HttpPost]
        [Route("UpdateVenue")]
        public async Task<ResponseModel> updateVenue(VenueModel venuemodel,int VenueId)
        {
            try

            {
                ResponseModel responseModel = new ResponseModel();
                var response = await venue.UpdateVenue(venuemodel,VenueId);
                if (response != null)
                {
                   
                    responseModel.Response = response;
                    responseModel.Status = true;
                    responseModel.Message = "veneue updated";
                    return responseModel;
                }
                else {
                    responseModel = new ResponseModel();
                    responseModel.Response = null;
                    responseModel.Status = false;
                    responseModel.Message = "veneue not updated";
                    return responseModel;
                }

            }
            catch (System.Exception ex)
            {
                ResponseModel responseModel = new ResponseModel();
                responseModel.Status = true;
                responseModel.Message = "Failure";
                responseModel.ErrorMessage = ex.Message;
                return responseModel;
            }
        }




        [HttpDelete]
        [Route("DeleteVenue")]
        public async Task<ResponseModel> DeleteVenue(int VenueId)
        {
            try
            {
                ResponseModel responseModel = new ResponseModel();  
                var response = await venue.DeleteVenue(VenueId);
                if (response!=null)
                {
                    responseModel.Response= response;
                    responseModel.Status = true;
                    responseModel.Message = "veneue deleted";
                    return responseModel;   
                }
                else
                {
                    responseModel.Status= false;
                    responseModel.Message = "veneue not deleted";
                    return responseModel;
                }
            }
            catch (System.Exception ex)
            {
                ResponseModel responseModel = new ResponseModel();
                responseModel.Status = true;
                responseModel.Message = "Failure";
                responseModel.ErrorMessage = ex.Message;
                return responseModel;
            }
        }
        }
    }




