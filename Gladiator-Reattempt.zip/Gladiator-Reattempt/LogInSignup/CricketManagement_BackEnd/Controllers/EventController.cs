﻿using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace CricketManagement.Controllers
{
    [ApiController]
    [Route("api/controller")]
    public class EventController : ControllerBase
    {
        private readonly IEvent _ievent;

        public EventController(IEvent ievent)
        {
            this._ievent = ievent;
        }

        [HttpPost]
        [Route("create")]
        public async Task<ResponseModel> Createevent(EventModel eventModel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                var Response = await _ievent.CreateEvent(eventModel);
                if(Response=="create is Done")
                {
                    responseModel.Status = true;
                    responseModel.Message = "created is done";
                    return responseModel;
                   
                }
                else
                {
                    responseModel.Status = false;
                    responseModel.Message = "creation failed";
                    return responseModel;
                }
            }
            catch (Exception ex)
            {

                responseModel.ErrorMessage = ex.Message; 
                responseModel.Status = false;   
                return responseModel;
            }
        }

        [HttpGet]
        [Route("ReadById")]
        public async Task<ResponseModel> ReadByEvents()
        { ResponseModel responseModel = new ResponseModel();    

            try
            {
                var Response = await _ievent.ReadByEvents();
                if (Response != null)
                {
                    responseModel.Response = Response;
                    responseModel.Status = true;
                    responseModel.Message = "element";
                    return responseModel;
                }
                else{
                    responseModel.Message = "no such event";
                    responseModel.Status = false;
                    responseModel.ErrorMessage = "Somthing went wrong";
                    return responseModel;
                }
            }
            catch (Exception ex)
            {

                responseModel.ErrorMessage = ex.Message;
                responseModel.Status = false;
                return responseModel;
            }
        }

        [HttpPost]
        [Route("Update")]
        public async Task<ResponseModel> UpdateEvent(EventModel eventModel, int eventId)
        {
            ResponseModel responseModel = new ResponseModel();  
            try
            {
               
               var Response = await _ievent.UpdateEvent(eventModel,eventId);
               if(Response == "Update is Create")
                {
                    responseModel.Message = Response;
                    responseModel.Status = true;    
                    return responseModel;
                }
                else
                {
                    responseModel.Message= Response;
                    responseModel.Status = false;
                    return responseModel;
                }
                
            }
            catch (Exception ex)
            {

                responseModel.ErrorMessage = ex.Message;
                responseModel.Status = false;
                return responseModel;

            }
        }

        [HttpDelete]
        [Route("Delete")]
        public async Task<ResponseModel> DeleteEvent(int eventId)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                var Response =await _ievent.DeleteEvent(eventId);
               if(Response=="DeleteEvent the Event")
                {
                    responseModel.Message = Response;
                    responseModel.Status = true;    
                    return responseModel;
                }
                else
                {
                    responseModel.Message= Response;
                    responseModel.Status = false;
                    return responseModel;
                }
            }
            catch (Exception ex)
            {

                responseModel.ErrorMessage = ex.Message;
                responseModel.Status = false;
                return responseModel;
            }
        }


    }
}
