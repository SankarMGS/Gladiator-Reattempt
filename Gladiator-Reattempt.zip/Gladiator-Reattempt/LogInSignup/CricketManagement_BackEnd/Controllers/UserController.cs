﻿using CricketManagement.Core.Interface;
using CricketManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using yogatraininghiringsystemproject.Core.Interface;


namespace yogatraininghiringsystemproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUser user;
        private readonly ILogger<UserController> logger;
        public UserController(IUser user, ILogger<UserController> logger)
        {
            this.user = user;
            this.logger = logger;
        }
        [HttpPost]
        [Route("addUser")]
        public async Task<ActionResult<ResponseModel>> addUser(UserModel data)
        {
            try
            {
                var res =await user.addUser(data);
                if (res != null)
                {
                    logger.LogInformation("user created");
                    ResponseModel response = new ResponseModel();
                    response.Response = new
                    {
                        data.UserRole,
                        data.UserName,
                        data.Email,
                        data.Password,
                        data.MobileNumber
                    };
                    response.Message = "Success";
                    response.Status = true;
                    
                    return response;
                }
                else
                {
                    ResponseModel response = new ResponseModel();
                    response.Message = "User not created successfully";

                    response.Status = false;
                    response.ErrorMessage = "Something wrong In else block";
                    logger.LogInformation("user not created");
                    return response;
                }
            }
            catch (Exception e)
            {
                ResponseModel response = new ResponseModel();
                response.Message = "error";

                response.Status = true;
                response.ErrorMessage = e.Message;
                logger.LogError($"{e.Message} at useradd");
                return response;

            }

        }


        [HttpDelete]
        [Route("deleteUser")]
        public async  Task<ActionResult<ResponseModel>> deleteUser(string UserID)
        {
            try
            {

                var res = await user.deleteUser(UserID);
                if (res != null)
                {
                    ResponseModel response = new ResponseModel();
                    response.Message = "user deleted";
                    response.Status = true;
                    logger.LogInformation("user deleted");
                    return response;
                }
                else
                {
                    ResponseModel response = new ResponseModel();
                    response.Message = "user not deleted";
                    response.Status = true;
                    response.ErrorMessage = null;
                    logger.LogInformation("user not deleted");
                    return response;
                }
            }
            catch (Exception e)
            {
                ResponseModel response = new ResponseModel();
                response.Message = "error";
                response.Status = true;
                response.ErrorMessage = e.Message;
                logger.LogError($"{e.Message} at userdeleted");
                return response;

            }

        }
        [HttpPut]
        [Route("editUser")]
        public async Task<ActionResult<ResponseModel>> editUser(int id,UserModel data)
        {
            try
            {
                var res =await user.editUser(id,data);
                if (res != null)
                {
                    ResponseModel response = new ResponseModel();
                    response.Message = "User Editted";

                    response.Status = true;
                    response.ErrorMessage = null;
                    logger.LogInformation("user edited");
                    return response;
                }
                else
                {
                    ResponseModel response = new ResponseModel();
                    response.Message = "User not Editted";

                    response.Status = true;
                    response.ErrorMessage = null;
                    logger.LogInformation("user not edited");
                    return response;
                }
            }
            catch (Exception e)
            {

                ResponseModel response = new ResponseModel();
                response.Message = "error";

                response.Status = true;
                response.ErrorMessage = e.Message;
                logger.LogError($"{e.Message} at useredited");
                return response;
            }

        }
        [HttpGet]
        [Route("getUser")]
        public async Task<ActionResult<UserModel>> getUser(string UserID)

        {
            try
            {

                logger.LogInformation("user by id");
                var response =await user.getUser(UserID);
                return response;
            }
            catch (Exception e)
            {
                logger.LogError($"{e.Message} at userbyid");
                throw;
            }

        }
    }
}
