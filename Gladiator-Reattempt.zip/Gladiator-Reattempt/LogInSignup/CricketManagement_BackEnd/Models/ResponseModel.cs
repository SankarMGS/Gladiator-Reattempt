﻿namespace CricketManagement.Models
{
    public class ResponseModel
    {
        public dynamic Response { get; set; }
        public string Message { get; set; }
        public bool? Status { get; set; }
        public string ErrorMessage { get; set; }
    }
}
