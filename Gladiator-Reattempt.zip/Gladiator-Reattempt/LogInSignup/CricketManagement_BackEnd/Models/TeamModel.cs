﻿using System.ComponentModel.DataAnnotations;

namespace CricketManagement.Models
{
    public class TeamModel
    {
        [Key]
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string teamDescription { get; set; }
        public int noOfplayers { get; set; }
        public string TeamLocation { get; set; }
        public string  FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; } 
        public string Gender { get; set; }
       


    }
}
